const DashboardHome = () => {
	return (
		<div>
			<h2 className="text-4xl"> AdminHome </h2>
		</div>
	);
};

export default DashboardHome;
