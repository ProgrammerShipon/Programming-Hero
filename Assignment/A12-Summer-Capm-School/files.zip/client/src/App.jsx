import "./App.css";

function App() {
	return (
		<>
			<h1 className="text-4xl"> Summer School </h1>
			<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque, a.</p>
		</>
	);
}

export default App;
